const form = document.getElementById("bookingForm");

form.addEventListener("submit", function(event){

    event.preventDefault();

    clearErrors();

    let valid = true;

    const fullName = document.getElementById("fullName");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const contact = document.getElementById("contact");
    const bookingId = document.getElementById("bookingId");

    // Task 4 - Blank Validation

    if(fullName.value.trim() === ""){
        showError(fullName,"nameError","Full Name is required");
        valid = false;
    }

    if(email.value.trim() === ""){
        showError(email,"emailError","Email Address is required");
        valid = false;
    }

    if(password.value.trim() === ""){
        showError(password,"passwordError","Password is required");
        valid = false;
    }

    if(confirmPassword.value.trim() === ""){
        showError(confirmPassword,"confirmError","Confirm Password is required");
        valid = false;
    }

    if(contact.value.trim() === ""){
        showError(contact,"contactError","Contact Number is required");
        valid = false;
    }

    if(bookingId.value.trim() === ""){
        showError(bookingId,"bookingError","Booking Reference ID is required");
        valid = false;
    }

    // Task 5 - Email Validation

    const emailValue = email.value.trim();

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if(emailValue !== "" && !emailPattern.test(emailValue)){
        showError(email,"emailError","Invalid Email Address");
        valid = false;
    }

    // Task 6 - Password Match Validation

    if(
        password.value !== "" &&
        confirmPassword.value !== "" &&
        password.value !== confirmPassword.value
    ){
        showError(confirmPassword,"confirmError","Passwords do not match");
        valid = false;
    }

    // Task 7 - Contact Number Validation

    const phonePattern = /^[0-9-]+$/;

    const digitsOnly = contact.value.replace(/-/g,"");

    if(contact.value !== ""){

        if(!phonePattern.test(contact.value)){
            showError(contact,"contactError","Only digits and hyphen allowed");
            valid = false;
        }

        if(digitsOnly.length > 11){
            showError(contact,"contactError","Maximum 11 digits allowed");
            valid = false;
        }
    }

    // Task 8 - Booking ID Validation

    const bookingPattern = /^TV-\d{4}$/;

    if(
        bookingId.value !== "" &&
        !bookingPattern.test(bookingId.value)
    ){
        showError(
            bookingId,
            "bookingError",
            "Format must be TV-2025"
        );
        valid = false;
    }

    // Task 9 - Success Message

    if(valid){

        document.getElementById("successMessage").textContent =
        "Booking Inquiry Submitted Successfully!";

        form.reset();
    }
});

function showError(input,id,message){

    input.classList.add("invalid");

    document.getElementById(id).textContent = message;
}

function clearErrors(){

    document.querySelectorAll(".error").forEach(function(error){
        error.textContent = "";
    });

    document.querySelectorAll("input").forEach(function(input){
        input.classList.remove("invalid");
    });

    document.getElementById("successMessage").textContent = "";
}